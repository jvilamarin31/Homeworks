import { useState } from 'react';
import PropTypes from 'prop-types';

const AddCategory = ({ onAdd }) => {
  // Paso 2: estado local para el input
  const [category, setCategory] = useState('');

  // Paso 1 y 3: onChange y envío del event a setCategory
  const onInputChange = (e) => {
    setCategory(e.target.value);
  };

  // Click o Enter en el form agregan la categoría
  const onSubmit = (e) => {
    e.preventDefault();
    onAdd(category);   // envía al Padre
    setCategory('');   // Paso 6: limpiar el input
  };

  return (
    <form onSubmit={onSubmit}>
      <input
        type="text"
        placeholder="Escribe una categoría…"
        value={category}
        onChange={onInputChange}
      />
      {/* Paso 4: botón para agregar */}
      <button type="submit">Agregar</button>
    </form>
  );
};

AddCategory.propTypes = {
  onAdd: PropTypes.func.isRequired,
};

export default AddCategory;
