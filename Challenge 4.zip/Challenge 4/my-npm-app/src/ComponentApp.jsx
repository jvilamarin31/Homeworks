import { useState } from 'react';
import AddCategory from './AddCategory';

const ComponentApp = () => {
  // Paso 5: estado con TODAS las categorías
  const [categories, setCategories] = useState([]);

  // Recibe una categoría desde el hijo y la agrega
  const handleAddCategory = (newCategory) => {
    const cat = newCategory.trim();
    if (!cat) return;                     // evita vacíos
    setCategories(prev => [...prev, cat]); // Paso 5: setCategories(...)
  };

  return (
    <>
      <h1>Categorías</h1>

      {/* Paso 7: dividir en Padre/Hijo. El Padre pasa el callback */}
      <AddCategory onAdd={handleAddCategory} />

      <ul>
        {categories.map((cat, idx) => (
          <li key={`${cat}-${idx}`}>{cat}</li>
        ))}
      </ul>
    </>
  );
};

export default ComponentApp;

