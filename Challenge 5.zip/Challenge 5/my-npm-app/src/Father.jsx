import { useState, useCallback, useMemo } from 'react';
import Son from './Son';

const Father = () => {
  const list = useMemo(() => [2, 4, 6, 8, 10], []);

  const [valor, setValor] = useState(0);     
  const [numero, setNumero] = useState(null); 

  const increment = useCallback((num) => {
    setValor((v) => v + num);
    setNumero(num);  
  }, []);

  return (
    <div>
      <h1>Father</h1>
      <p>Total: {valor}</p>
      <p>numero: {numero ?? '-'}</p>
      <hr />
      {list.map((n) => (
        <Son key={n} numero={n} increment={increment} />
      ))}
    </div>
  );
};

export default Father;
