import React from 'react';

const Son = React.memo(({ numero, increment }) => {
  console.log('render <Son>', numero);
  return (
    <button
      className="btn btn-primary mr-3"
      onClick={() => increment(numero)}
    >
      {numero}
    </button>
  );
});

export default Son;
