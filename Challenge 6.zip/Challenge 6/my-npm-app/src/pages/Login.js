import { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const [username, setUsername] = useState("");
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // Si venía de una privada, vuelve allá; si no, al dashboard
  const from = location.state?.from?.pathname || "/dashboard";

  const handleSubmit = (e) => {
    e.preventDefault();
    const name = username.trim();
    if (!name) return;
    login(name);                       // FAKE login
    navigate(from, { replace: true }); // redirección + bloquea "Atrás"
  };

  return (
    <form onSubmit={handleSubmit} style={{ display: "grid", gap: 8, maxWidth: 320 }}>
      <h2>Login (FAKE)</h2>
      <input
        placeholder="username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <button type="submit">Entrar</button>
      <p style={{ fontSize: 12, color: "#555" }}>Tip: escribe cualquier usuario y entra.</p>
    </form>
  );
}
