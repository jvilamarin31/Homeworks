export default function Dashboard() {
  return <h2>Ruta privada: Dashboard</h2>;
}
