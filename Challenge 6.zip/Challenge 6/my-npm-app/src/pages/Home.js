export default function Home() {
  return <h2>Página pública: Home</h2>;
}
