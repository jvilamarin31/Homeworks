import { Link, Routes, Route, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "./context/AuthContext";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Profile from "./pages/Profile";
import RequireAuth from "./components/RequireAuth";

export default function App() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    // Evita volver con el botón Atrás
    navigate("/login", { replace: true });
  };

  return (
    <>
      <header style={{ display: "flex", gap: 12, padding: 12, borderBottom: "1px solid #ddd" }}>
        <Link to="/">Home</Link>
        <Link to="/dashboard">Dashboard</Link>
        <Link to="/profile">Profile</Link>

        {user ? (
          <>
            <span style={{ marginLeft: "auto" }}>
              Bienvenido, <strong>{user.username}</strong>
            </span>
            <button onClick={handleLogout}>Logout</button>
          </>
        ) : (
          <Link style={{ marginLeft: "auto" }} to="/login">Login</Link>
        )}
      </header>

      <main style={{ padding: 16 }}>
        <Routes>
          {/* Públicas */}
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />

          {/* Privadas */}
          <Route element={<RequireAuth />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/profile" element={<Profile />} />
          </Route>

          {/* 404 → Home */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </>
  );
}

