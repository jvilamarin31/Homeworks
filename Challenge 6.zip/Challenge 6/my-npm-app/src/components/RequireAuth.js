import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function RequireAuth() {
  const { user } = useAuth();
  const location = useLocation();

  if (!user) {
    // Redirige a /login y recuerda desde dónde venía
    return <Navigate to="/login" replace state={{ from: location }} />;
  }
  return <Outlet />;
}
